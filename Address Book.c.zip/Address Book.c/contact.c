#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>
 

    // Listing (Sorting) -> Functions

int comparebyName(const void *a , const void *b)    //Fuction to compare name
{
    return strcmp(((Contact *)a) -> name , ((Contact *)b)->name); 
}

int comparebyPhone(const void *a , const void *b)  // Function to compare phone
{
    return strcmp(((Contact *)a) -> phone , ((Contact *)b) -> phone); 
}

int comparebyemail(const void * a , const void * b)  // Function to compare email
{
    return strcmp(((Contact *)a) -> email , ((Contact *)b) -> email); 
}
 // Create ->  Fuctions

// Function definition -> To validate name -> No -> Integer , symbols , special Character. Yes -> Space , Alphabets
int validate_name(char * name)
{
    int name_len = strlen(name);
    for(int j = 0 ; j < name_len ; j++)
    {
        if(! isalpha(name[j]) && name [j] != ' ')
        {
            return 0 ;
        }
        
    }
    return 1;
}

//Function definition -> To validate contact number -> No -> Alphabet , Symbols , Special Characters , Space. Yes -> Only Integer
int validate_contact(char * phone)
{
    int phone_len = strlen(phone);
    for(int j = 0 ; j < phone_len ; j++)
    {
        if(! isdigit(phone[j]))
        {
            return 0;
        }
    }
     return 1 ;
}


// Function Definition -> To validate email id -> No -> space , quotes , comma , symbol . Yes -> Alphabets , integer , @ , .com
int validate_email(char * email)
{
    
        if(strchr(email, ' ') != NULL)
        return 0;
        
        char *at = strchr(email , '@');
        if(at == NULL)
        return 0;

        if(at == email)
        return 0;

        char *dot = strstr(at , ".com");
        if(dot == NULL)
        return 0;

        if(at[1] == '.' || at[1] == '\0')
        return 0;

        return 1 ;

}

// Sort contacts based on the chosen criteria
void listContacts(AddressBook *addressBook, int sortCriteria)
{
    int i = 0 ;
    loadContactsFromFile(addressBook);

    if(addressBook -> contactCount == 0)
    {
        printf("No Contacts to display. \n");
        return ;
    }

    switch (sortCriteria)
    {
        case 1 : 
        // Sorting contact by name
        qsort(addressBook -> contacts , addressBook -> contactCount , sizeof(Contact) , comparebyName);
        printf("Contacts sorted by Name : \n");
        break ;

        case 2 :
        // Sorting contact by contact number
        qsort(addressBook -> contacts , addressBook -> contactCount , sizeof(Contact) , comparebyPhone);
        printf("Contacts sorted by phone : \n");
        break ;

        case 3 :
        // Sorting contact by email
        qsort(addressBook -> contacts , addressBook -> contactCount , sizeof(Contact) , comparebyemail);
        printf("Contacts sorted by Email: \n");
        break ;

        default:
        // If user didn't entered options from 1 to 3 -> default will get executed
        printf("Invalid sort option. Displaying unsorted list.\n");
        break ;
    }


// Displaying sorted array
printf("\n%-20s %-15s %-30s\n","Name" , "Contact Number" , "Email ID" ); 
// %-20s %-15s %-30s -> tells name has a width 20 which is left aligned
// Contact number has a width of 15 which is left aligned
// email id has a width of 30 which is left aligned


for(int j = 0 ; j < addressBook -> contactCount ; j++)
{
    printf("%-20s %-15s %-30s\n",addressBook -> contacts[j].name , addressBook -> contacts[j] . phone , addressBook -> contacts[j] . email);

}
}
    

void initialize(AddressBook *addressBook) 
{
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) 
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
	/* Define the logic to create a Contacts */
    //int validate_name(char name);          //Function Protocol
    //int validate_contact_no(char phone);   //Function Protocol
    //int validate_email(char email);        //Function Protocol
    char new_name[50];
    char new_phone[20];
    char new_email[50];

    loadContactsFromFile(addressBook);
    
    // Flags 
    int name = 0 ; 
    int phone = 0 ;
    int email = 0 ;


    printf("Enter your name : ");
    getchar(); // Removes \n 
    scanf("%49[^\n]",new_name); // Storing user's name in the structure 
    getchar();
    printf("Enter your Contact_number : ");
    scanf("%49[^\n]",new_phone); // Soring user's contact number in the structure
    getchar();
    printf("Enter your email_id : ");
    scanf("%49[^\n]",new_email); // Storing user's email id in the structure

    if(validate_name(new_name) == 1) //Validating the name 
    {
        name = 1 ; // Declaring flag as 1
        if(validate_contact(new_phone) == 1) //Validating the contact number
        {
            phone = 1 ; // Declaring flag as 1
            if(validate_email(new_email) == 1) //Validating the email Id 
            {
                email = 1 ; // Declaring flag as 1
                addressBook -> contactCount ++ ;  //Incrementing the array count 
                printf("Your Informations are registered successfully in the addressbook \n"); //If everything is validated successfully, the complier prints this printf statement 
                strcpy(addressBook -> contacts[addressBook -> contactCount - 1].name , new_name) ;
                strcpy(addressBook -> contacts[addressBook -> contactCount - 1].phone , new_phone) ;
                strcpy(addressBook -> contacts[addressBook -> contactCount - 1].email , new_email);
                return ;
            }
        }
    }
    if(name == 0) 
    {
        printf("Enter Alphabets Only \n");
        printf("Check your numbere and email ID as well \n");
        return ;
    
    }
    if(phone == 0 )
    {
        printf("Enter Numbers Only. \n");
        printf("Check your email ID as well \n");
        return ;
    }
    if(email == 0)
    {
        printf("Enter E-mail ID in the correct format. \n");
        printf("----------Please Try Again---------- \n");
        return  ;
    }
 
    
}

void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
     char search_name[50]; //
    char search_phone[20];
    char search_email[50];
    loadContactsFromFile(addressBook);


    int option; 
    printf("Enter which information do you know about the user \n");
    printf("Click 1 -> Name \n");
    printf("Click 2 -> phone \n");
    printf("Click 3 -> email \n");
    printf("Enter : ");
    scanf("%d",&option);
    getchar(); // Removes \n which gets automatically created when an interger being stored -> so it won't affect the next string
    
    int search = 0; // Flag
    switch(option)   //Switch case to search the information
    {
        case 1:
        printf("Enter the name to be searched : ");
        scanf("%49[^\n]",search_name);
        getchar(); //Removes the leftover \n
        for(int i = 0 ; i < addressBook -> contactCount ; i ++)
        {
        if(stricmp(addressBook -> contacts[i].name , search_name) == 0) // stricmp will check both upper & lower case
        {
            search = 1 ; // Flag is declared as 1
            printf("Name : %s",addressBook -> contacts[i].name); // If name is found, it displays the name , 
            printf("Phone : %s \n",addressBook -> contacts[i].phone); // contact number , 
            printf("Email ID : %s \n",addressBook -> contacts[i].email); // email id of the user in the console
          
        }
        }
        if(search == 0) // If the name is not found, flag tends to be 0, now if conditon works
        {
            printf("The name : %s you have entered is not existing in AddressBook. \n",search_name);
        }
         
        break ; //End of case 1.

        case 2:
        printf("Enter the mobile number to be searched : ");
        scanf("%19[^\n]",search_phone); 
        getchar(); //Removes the leftover \n
        for(int i = 0 ; i < addressBook -> contactCount ; i ++)
        {
        if(strcmp(addressBook -> contacts[i].phone , search_phone) == 0) // Here no need of stricmp bcoz its a number
        {
            search = 1 ;
            printf("Name : %s\n",addressBook -> contacts[i].name); // If entered contact number is found -> displays the name of the specific contact number
            printf("Phone : %s \n",addressBook -> contacts[i].phone); // Displays contact number
            printf("Email ID : %s \n",addressBook -> contacts[i].email); // Displays email id at the console
          
        }
        }
        if(search == 0) // If entered contact number is not present -> if condition works
        {
            printf("The contact number : %s you have entered is not existing in AddressBook \n",search_phone);
        } 
        break ; // End of case 2.

        case 3:
        printf("Enter the E-mail ID to be searched : ");
        scanf("%49[^\n]",search_email);
        getchar(); //Removes the leftover \n
        for(int i = 0 ; i < addressBook -> contactCount ; i ++) // to check one by one of the array of structure 
        {
        if(strcmp(addressBook -> contacts[i].email , search_email) == 0) // No need of stricmp bcoz email needs to perfectly matched. 
        {
            search = 1 ; // Flag is declared as 1
            printf("Name : %s",addressBook -> contacts[i].name); // IF email id is found then name of that particular email id will get displayed in the console
            printf("Phone : %s \n",addressBook -> contacts[i].phone); // Phone number will get displayed
            printf("Email ID : %s \n",addressBook -> contacts[i].email); // email id will ger displayed
          
        }
        }
        if(search == 0) // If email is not found inside the structure then the compiler gets inside this if condition
        {
            printf("The E-mail ID : %s you have entered is not existing in AddressBook \n",search_email);
        }
       
        break ; // End of case 3.

        default: // if user entered invalid input / above 3 -> default gets executed 
        printf("Enter numbers from 1 to 3 according to your requirement. \n");
    } 
}


void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
    int editoption ;

    //Initilizing the string size 
    char name_to_be_edited[50]; 
    char phone_to_be_edited[20];
    char email_to_be_edited[50];

    char new_name[50];
    char new_phone[20];
    char new_email[50];

    loadContactsFromFile(addressBook);
    // Display on the console
    printf("Click 1 --> To edit name \n");
    printf("Click 2 --> To edit contact number \n");
    printf("Click 3 --> To edit email Id \n ");
    printf("Enter : ");
    scanf("%d",&editoption);
    getchar(); //Removes the leftover \n

    int found = 0 ;
    switch (editoption)
    {
        case 1 :
        printf("Enter name to be edited : ");
        scanf("%49[^\n]",name_to_be_edited);
        getchar() ; //Removes the leftover \n
        for(int i = 0 ; i < addressBook -> contactCount ; i ++)
        {
            if(stricmp(addressBook -> contacts[i].name , name_to_be_edited) == 0 ) // Checks for both the lower & upper case
            {
                found = 1 ; 
                printf("Enter new name : ");
                scanf("%49[^\n]",new_name);
                getchar(); //Removes the leftover \n
                strcpy(addressBook -> contacts[i].name , new_name); // Rewriting the new name on the old name
                printf("%s is edited successfully. \n",addressBook -> contacts[i].name );
            }
        }
        if(found == 0) // If name is not found -> if condion will get executed
        {
            printf("%s is not found in AddressBook \n",name_to_be_edited);
            printf("Try Again By Giving The Correct Name. \n");
        }
        break ; // End of case 1

        case 2 :
        printf("Enter the contact number to be edited : ");
        scanf("%19[^\n]",phone_to_be_edited);
        getchar();
        for(int i = 0 ; i < addressBook -> contactCount ; i ++)
        {
            if(strcmp(addressBook -> contacts[i].phone , phone_to_be_edited) == 0) // No need of stricmp -> all are numbers 
            {
                found = 1 ; // If contact number is matched  found is declared as 1 
                printf("Enter new contact number : ");
                scanf("%19[^\n]",new_phone);
                getchar();
                strcpy(addressBook -> contacts[i].phone , new_phone); // Rewrite the new phone number on the old phone number
                printf("%s is edited successfully \n",addressBook -> contacts[i].phone);
            }
        }
        if(found == 0 ) // If phone number is not matched -> if conditon works
        {
            printf("%s is not found in the AddressBook \n",phone_to_be_edited);
            printf("Try Again By Giving The Correct Contact Number. \n");
        }
        break ; // End of case 2

        case 3 :
        printf("Enter email id to be edited : ");
        scanf("%49[^\n]",email_to_be_edited);
        getchar();
        for(int i = 0 ; i < addressBook -> contactCount ; i ++)
        {
            if(strcmp(addressBook -> contacts[i].email , email_to_be_edited) == 0) // All elements of the email should be perfect, so stricmp is not used
            {
                found = 1 ; // If email is matched -> found is declared as 1
                printf("Enter new E-mail ID : ");
                scanf("%49[^\n]",new_email); //Stores the new email id
                getchar();
                strcpy(addressBook -> contacts[i].email , new_email); // Rewrite the new email id on the old email id
                printf("%s is edited successfully \n",addressBook -> contacts[i].email);
            }
        }
        if(found == 0) // If entered email id is not found -> if condtion will work
        {
            printf("%s is not found in the AddressBook \n",email_to_be_edited);
            printf("Try Again By Giving The Correct E-mail ID. \n");
        }
        break ; // End of case 3

        // If user didn't entered 1 / 2 / 3 options -> default gets executed
        default : 
        printf("Enter numbers from 1 to 3 according to your niche \n");
        printf("\n") ;
    }
    
}



void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */
    int i = 0;
    int check_wether_name_found = 0 ;
    int check_wether_phone_found = 0 ;
    int check_wether_email_found = 0 ;
    char user_name[50];
    char user_phone[20];
    char user_email[50];
    int empty_string ;

    loadContactsFromFile(addressBook);

    printf("Enter your name : ");
    while(getchar() != '\0'); //Flush the newline from input buffer before using scanf
    scanf("%49[^\n]",user_name);
    printf("Enter your phone : ");
    while(getchar() != '\0'); //Flush newline from the input buffer before using scanf
    scanf("%19[^\n]",user_phone);
    printf("Enter your email : ");
    while(getchar() != '\0'); //Flush newline form the input buffer before using scanf
    scanf("%49[^\n]",user_email);

    for(int i = 0 ; i < addressBook -> contactCount ; i ++)
    {
        if(stricmp(addressBook -> contacts[i].name , user_name) == 0) //  Compare entered name with the existing name present inside the array of structure
        {
            check_wether_name_found = 1 ; // If the if condition is not true then check_whethe_name_match will remain 0 so it will be easy to write an 
                                          //else statement after the complier reach the outside of the for loop
            if(stricmp(addressBook -> contacts[i].phone , user_phone) == 0) //Compare entered phone number with the existing phone numbers in the array of structure
            {
                check_wether_phone_found = 1 ;
                if(stricmp(addressBook -> contacts[i].email , user_email)== 0) //Compare entered email with the existing email id in the array of structure
                {
                    check_wether_email_found = 1 ;
                    for(int j = i ; j < addressBook -> contactCount ; j ++)
                    {
                        strcpy(addressBook -> contacts[j].name , addressBook -> contacts[j + 1].name) ; //Copying the next array in the present array
                        strcpy(addressBook -> contacts[j].phone , addressBook -> contacts[j + 1].phone) ;
                        strcpy(addressBook -> contacts[j].email , addressBook -> contacts[j + 1].email) ;
                        empty_string = j;
                    }

                    //Declaring last arrays strings as empty string
                    addressBook -> contacts[empty_string].name[0] = '\0'; 
                    addressBook -> contacts[empty_string].phone[0] = '\0';
                    addressBook -> contacts[empty_string].email[0] = '\0';                    
                }
            
            }
        }
       
    }
    if(check_wether_name_found == 0 || check_wether_phone_found == 0 || check_wether_email_found == 0)
    {
        printf("The given details is not found in the AddressBook. \n");
        printf(" ---------- TRY AGAIN ---------- \n");
    }
   
}
