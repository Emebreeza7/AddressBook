#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook)
 {
    FILE *fp = fopen("contacts.txt","w+"); // Opening the file and opend it in write + mode -> overwrites content on the file
  
    if(fp == NULL) // If fopen returns NULL , then if condition will work 
    {
    printf("Warning : Error Opening the File \n");
    return ; // Stops the program here
    }
 
    for(int i = 0 ; i < addressBook -> contactCount ; i ++)
    {
     // Saving the data from memory (structure addressbook) to the file
    fprintf(fp , "%49s %19s %49s\n" , addressBook -> contacts[i].name , addressBook -> contacts[i].phone ,  addressBook -> contacts[i].email);
    }
    fclose(fp); // Closing the file
    printf("Saved Successfully \n"); // Will get printed in the console
  
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE * fp = fopen("contacts.txt" , "r"); // Opeing the file (user_info.txt) in the read mode
    
    if(fp == NULL) // If fopen returns Null -> this if conditon works
    {
        printf("No contents in the file. \n");
    }
    int i = 0 ; //Initializing i with 0 
    while(fscanf(fp , "%49s %19s %49s" , addressBook -> contacts[i].name , addressBook -> contacts[i].phone , addressBook -> contacts[i].email) == 3 )
    {
        i ++ ; // Incrementing i -> to assign i in the contacts count

        // If i exceeds 100, if condition works
        if(i >= MAX_CONTACTS) // MAX_CONTACTS is a macro of size 100  
        {
            printf("Warning : The contacts exceeds the limit \n");  
            return ; // Stops here
        }
    }
    addressBook -> contactCount = i ; // Assigning i to the contact count (Structure addressbook)
    fclose(fp); // Close the file
    
}
